import React, { useEffect, useState ,useRef} from "react";
import { Sidebar } from "../sidebar/Sidebar";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  PieChart,
  Pie,
  Legend,
} from "recharts";
import axios from "axios";
import './index.css';
import { Bookingcardprops } from "./Bookingcardprops";
import { Header } from "../header/Header";
import moment from "moment";
import { useReactToPrint } from "react-to-print";

export const Index = () => {

  const componentPDF = useRef();
  const [getbooking, setbooking] = useState([]);
  console.log(getbooking);
  useEffect(() => {
    const registerAppointment = async () => {
      axios
      .get("http://localhost:3000/booking/view")
      .then((res) => {
        // console.log(res.data.data);
        setbooking(res.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
    };
    registerAppointment();
  });

  const genratePDF = useReactToPrint({
    content: () => componentPDF.current,
    documentTitle: "bookingdata",
    // onAfterPrint: () => alert("data saved in pdf"),
  });


  const [getbookdata, setbookdata] = useState([]);
  // console.log(getbookdata);
  useEffect(() => {
    axios
      .get("http://localhost:3000/booking/view")
      .then((res) => {
        // console.log(res.data.data);
        setbookdata(res.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  });

  const filteredBookDataByJunior = getbookdata.filter(
    (booking) => booking.room === "Junior Suite"
  );
  const totalJunior = filteredBookDataByJunior.length
  // console.log(filteredBookDataByRoom);
  const filteredBookDataByLuxury = getbookdata.filter(
    (booking) => booking.room === "Luxury Room"
  );
  const totalLuxury = filteredBookDataByLuxury.length
  // console.log(filteredBookDataByLuxury);
  const filteredBookDataBySuper = getbookdata.filter(
    (booking) => booking.room === "Super Deluxe"
  );

  const SuperDeluxe = filteredBookDataBySuper.length
  // console.log(filteredBookDataBySuper);

  const totelbooking = getbookdata.length;
  // console.log(totelbooking);




  /**************************services */
  const [getservicedata, setservicedata] = useState([]);
  // console.log(getservicedata);

  const totalservice = getservicedata.length;

  useEffect(() => {
    axios
      .get("http://localhost:3000/service/view")
      .then((res) => {
        // console.log(res.data.data);
        setservicedata(res.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  });



  /****************************room */
  const [getroomdata, setroomdata] = useState([]);
  // console.log(getservicedata);

  const totalroom = getroomdata.length;

  useEffect(() => {
    axios
      .get("http://localhost:3000/room/view")
      .then((res) => {
        // console.log(res.data.data);
        setroomdata(res.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  });


  /************************our team */

  const [getstaffdata, setstaffdata] = useState([]);
  // console.log(getservicedata);

  const totalstaff = getstaffdata.length;

  useEffect(() => {
    axios
      .get("http://localhost:3000/staff/view")
      .then((res) => {
        // console.log(res.data.data);
        setstaffdata(res.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  });


  const data = [
    { name: "total booking", number: totelbooking, pv: 2400, amt: 2400 },
    { name: "total service", number: totalservice, pv: 2400, amt: 2400 },
    { name: "total room", number: totalroom, pv: 2400, amt: 2400 },
    { name: "total staff", number: totalstaff, pv: 2400, amt: 2400 },
  ];


  const data01 = [
    { name: "Junior Suite Room", value: totalJunior },
    { name: "Luxury Room", value: totalLuxury },
    { name: "Super Deluxe", value: SuperDeluxe },

  ];


  const delhandel1= (e) => {
    console.log(e);
    axios
      .delete(`http://localhost:3000/booking/delete/${e}`)
      .then((res) => {
        console.log(res);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  return (
    <Sidebar
      index={
        <>
          <Header />
          <div>
            <div className="card-contanier d-flex" style={{ justifyContent: "space-around" }}>
              <div class="card1 c1_card">
                <div class="card1-details1">
                  <div className="text-title1" style={{ fontSize: "200%" }}>
                    <i class="fa-solid fa-calendar-plus" />
                  </div>
                  <p class="text-title1">Total Booking</p>
                  <p class="text-body1"> {totelbooking}</p>
                </div>
              </div>
              <div class="card1 c2_card">
                <div class="card1-details1">
                  <div className="text-title1" style={{ fontSize: "200%" }}>
                    <i class="fa-solid fa-calendar-plus" />
                  </div>
                  <p class="text-title1">Total Service</p>
                  <p class="text-body1">{totalservice}</p>
                </div>
              </div>
              <div class="card1 c3_card">
                <div class="card1-details1">
                  <div className="text-title1" style={{ fontSize: "200%" }}>
                    <i class="fa-solid fa-calendar-plus" />
                  </div>
                  <p class="text-title1">Total Room</p>
                  <p class="text-body1"> {totalroom}</p>
                </div>
              </div>
              <div class="card1 c4_card">
                <div class="card1-details1">
                  <div className="text-title1" style={{ fontSize: "200%" }}>
                    <i class="fa-solid fa-calendar-plus" />
                  </div>
                  <p class="text-title1">Total Staff</p>
                  <p class="text-body1"> {totalstaff}</p>
                </div>
              </div>
            </div>


            <h1 style={{ marginTop: "30px" }}>Overall Report</h1>
            <div style={{ padding: "50px", marginLeft: "200px" }}>

              <BarChart width={1000} height={400} data={data}>
                <XAxis dataKey="name" stroke="#8884d8" />
                <YAxis />
                <Tooltip />
                <CartesianGrid stroke="#ccc" strokeDasharray="5 5" />
                <Bar dataKey="number" fill="#8884d8" barSize={30} />
              </BarChart>
            </div>


            <h1 style={{ marginTop: "30px" }}>Booking Details</h1>
            <div className="container2">
              <div ref={componentPDF}>
              <table className="table table-bordered" style={{ marginLeft: "100px", width: "90%"}}>
                <thead>
                  <tr>
                    <th scope="col">No</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Checkin</th>
                    <th scope="col">Checkout</th>
                    <th scope="col">Adult No</th>
                    <th scope="col">Child No</th>
                    <th scope="col">Room</th>
                    <th scope="col">Message</th>
                    <th scope="col">Delete</th>
                  </tr>
                </thead>
                <tbody>
                  {getbookdata.map((el, index) => {
                const date = moment(el.checkin).format("DD/MM/YYYY");  
                const date1 = moment(el.checkout).format("DD/MM/YYYY");  
                    return (
                      <Bookingcardprops
                      counter = {index+1}
                        name={el.name}
                        email={el.email}
                        checkin={date}
                        checkout={date1}
                        adultno={el.adultno}
                        childno={el.childno}
                        room={el.room}
                        message={el.message}
                        delete={
                          <i 
                            className="fa-solid fa-trash-can"
                            onClick={() => delhandel1(el._id)}
                          />
                        }
                      />
                    );
                  })}
                </tbody>
              </table>
              </div>
            </div>
            <div>
              <button type="submit"  onClick={genratePDF}>PDF</button>
            </div>

            <div>
              <PieChart width={1000} height={400}>
                <Pie
                  dataKey="value"
                  isAnimationActive={false}
                  data={data01}
                  cx={200}
                  cy={200}
                  outerRadius={80}
                  fill="#8884d8"
                  label
                />
                <Tooltip />

              </PieChart>
            </div>

          </div>
        </>

      }
    />
  );
};
